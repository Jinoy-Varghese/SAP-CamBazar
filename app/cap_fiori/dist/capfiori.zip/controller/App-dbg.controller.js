sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("capfiori.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  